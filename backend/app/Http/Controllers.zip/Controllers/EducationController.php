<?php

namespace App\Http\Controllers;

use App\Models\Education;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class EducationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();
        
        // If user is a candidate, show only their educations
        if ($user->isCandidate()) {
            $educations = $user->candidate->educations()->orderByDesc('start_date')->get();
            
            return response()->json([
                'status' => 'success',
                'data' => $educations
            ]);
        }
        
        return response()->json([
            'status' => 'error',
            'message' => 'Unauthorized'
        ], 403);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): JsonResponse
    {
        $user = $request->user();
        
        // Ensure user is a candidate
        if (!$user->isCandidate()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Only candidates can add education'
            ], 403);
        }
        
        $request->validate([
            'institution' => 'required|string|max:255',
            'degree' => 'required|string|max:255',
            'field_of_study' => 'required|string|max:255',
            'start_date' => 'required|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
            'is_current' => 'boolean',
            'description' => 'nullable|string'
        ]);
        
        $education = $user->candidate->educations()->create([
            'institution' => $request->institution,
            'degree' => $request->degree,
            'field_of_study' => $request->field_of_study,
            'start_date' => $request->start_date,
            'end_date' => $request->is_current ? null : $request->end_date,
            'is_current' => $request->is_current ?? false,
            'description' => $request->description
        ]);
        
        return response()->json([
            'status' => 'success',
            'message' => 'Education added successfully',
            'data' => $education
        ], 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(Education $education): JsonResponse
    {
        $user = request()->user();
        
        // Ensure user has permission to view this education
        if ($user->isCandidate() && $user->candidate->id !== $education->candidate_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'You do not have permission to view this education'
            ], 403);
        }
        
        return response()->json([
            'status' => 'success',
            'data' => $education
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Education $education): JsonResponse
    {
        $user = $request->user();
        
        // Ensure user has permission to update this education
        if ($user->isCandidate() && $user->candidate->id !== $education->candidate_id) {
            return response()->json([
                'status' => 'error',
                'message' => 'You do not have permission to update this education'
            ], 403);
        }
        
        $
